### `npm install` // /node-user-authentication
### `node server.js`
	Runs node server listening at port# 8080


### `npm install` // /signup-form 
### `npm start`
	Runs the app in the development mode.<br />
	Open [http://localhost:3000](http://localhost:3000) to view it in the browser.
	
	
### Demo video
	demo..wrf