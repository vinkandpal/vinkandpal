import React, {useState} from 'react';

import './Password.scss';
import PropTypes from "prop-types";
import PasswordField from '../../../components/UI/Input/PasswordField';
import Button from '../../../components/UI/Button/Button';
import FormHeader from '../../../components/FormHeader/FormHeader';
import BaseService from '../../../app/services/BaseService';

const PasswordComp = ( {data, ...props} ) => {
    const [ userPassword, setuserPassword ] = useState();
    const [ validPassword, setValidPassword ] = useState(true);

    const verifyPassword = ()=>{
        BaseService.makecall({url: '/users/verifyPwd', data: {'Username': data.Username, 'Password': userPassword}})
            .then((response) => {
              if(response.data === 'Success'){
                setValidPassword(true);
                alert('You are successfully logged in!')
              }

            })
            .catch((error) => {
              setValidPassword(false);
            });
    };

    const userPasswordHandler = (e)=>{
        let userPassword = e.target.value;
        setuserPassword(userPassword);
    };

    const submitHandler = (e)=>{
        e.preventDefault();
        verifyPassword();
    };

    const backHandler = ()=>{
        props.navigate('signIn');
    };
    
    return (
        <div className='welcome-wrap'>
            <FormHeader screenType='welcome' classes='welcome-wrap__header text-center' backIcon backHandler={backHandler} />
            <div className="welcome-wrap__user text-center">{data.Username}</div>
            <div className="row welcome-wrap__password">
                <div className="col-xs-12 password">
                    <PasswordField
                        label = {'Password'}
                        value={userPassword}
                        placeholder=''
                        inputclass = 'form-control'
                        id="password"
                        aria-label="Email text field"
                        onChange={userPasswordHandler} 
                        autoFocus="autofocus" 
                        autoCorrect="off" 
                        autoCapitalize="off" 
                        data-val="true" 
                        data-val-required="Please enter an email" 
                        max-length="20"
                        tabIndex="1" 
                        valid={userPassword}
                        showPassword={true} 
                        error={!validPassword}
                        errorMessage='The entered password is incorrect.'
                        />
                </div>
            </div>
            <div className="row welcome-wrap__sign-btn">
                <div className="col-xs-12">
                    <Button
                        classes="btn btn-primary btn-lg btn-block"
                        size="md"
                        variant="primary"
                        fullWidth={true}
                        label='Sign in'
                        autoid="login-page-button-submit-button"
                        onClick={submitHandler}
                        data-loading-text="Verifying..."
                        aria-label="Next button" 
                        id="verify_user_btn" 
                      ></Button>
                </div>
            </div>
        </div>
    );
};

export default PasswordComp;