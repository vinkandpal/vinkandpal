import React, { useState, useEffect } from 'react';

import classes from './UserName.scss';
import Button from '../../../components/UI/Button/Button';
import Toast from '../../../components/UI/Toast/Toast';
import TextField from '../../../components/UI/Input/TextField'
import FormHeader from '../../../components/FormHeader/FormHeader';
import BaseService from '../../../app/services/BaseService';

const UserNameComp = ( {data, ...props} ) => {
    let btnStyle = { color: props.currentProvider },
        navigate = props.navigate,
        showToastMsg = data && data.accountCreated,
        uName = data && data.Username || '';

    const [ userName, setUserName ] = useState(uName);
    const [ validUsername, setValidUsername ] = useState(true);
    const [ btnContent, setBtnContent ] = useState('Next');
    
    const verifyUsername = ()=>{
        BaseService.makecall({url: '/users/login', data: {'Username':userName}})
            .then((response) => {
              if(response.data === 'Success'){
                navigate('Password', {'Username':userName});
              }

            })
            .catch((error) => {
              setValidUsername(false);
              setBtnContent('Next');
            });
    };

    const NextBtnHandler = ()=>{
        setBtnContent('Verifying...');
        verifyUsername();
    };

    const userNameHandler = (e)=>{
        let userName = e.target.value;
        setUserName(userName);
    };

    return (
        <>
            { showToastMsg && 
                <Toast content='signin-success' classes='signin-wrap__toast' />
            }
            <div className="signin-wrap__username-cont">
                <FormHeader screenType='sign-in' classes='signin-wrap__header' />
                <div className="row signin-wrap__username">
                    <div className="col-xs-12">
                            <TextField
                                label = {'Username'}
                                value={userName}
                                placeholder=''
                                inputclass = 'form-control'
                                id="userName"
                                aria-label="Email text field"
                                onChange={userNameHandler} 
                                autoFocus="autofocus" 
                                autoCorrect="off" 
                                autoCapitalize="off" 
                                data-val="true" 
                                data-val-required="Please enter an email" 
                                max-length="20"
                                tabIndex="1" 
                                valid={userName}
                                allowCopyPaste={true}
                                error={!validUsername}
                                errorMessage='The username is not recognized.'
                                />
                    </div>
                </div>
                <div className="row signin-wrap__next-btn">
                    <div className="col-xs-12">
                        <Button
                            style={btnStyle}
                            classes="btn btn-primary btn-lg btn-block"
                            size="md"
                            variant="primary"
                            fullWidth={true}
                            label={btnContent}
                            autoid="login-page-button-submit-button"
                            onClick={NextBtnHandler}
                            data-loading-text="Verifying..."
                            aria-label="Next button" 
                            id="verify_user_btn" 
                          ></Button>
                    </div>
                </div>
            </div>
        </>
    );
};

export default UserNameComp;