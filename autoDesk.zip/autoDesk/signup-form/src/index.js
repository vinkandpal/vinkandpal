import AppBootstrap from './app-bootstrap'

let appBootstrap = new AppBootstrap()
appBootstrap.init(); // Bootstraps the application