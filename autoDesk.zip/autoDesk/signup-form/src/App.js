import React from 'react'
import Layout from './hoc/Layout/Layout';

const App = (props) => {
  return (
      <Layout {...props} /> 
  )
}
export default App;