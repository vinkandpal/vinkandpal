import React from 'react';
import ReactDOM from 'react-dom';

import App from './App';
import 'bootstrap/dist/css/bootstrap.css';
import './app/styles/App.scss';

class AppBootstrap {

    init() {
        this.renderView()
    }

    renderView() {
        ReactDOM.render(<App route='signIn' />, document.getElementById('root'))
    }
}

export default AppBootstrap